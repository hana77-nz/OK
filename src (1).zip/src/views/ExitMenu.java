package views;

public class ExitMenu extends AppMenu {
    public void showMassage(String name){}
}
